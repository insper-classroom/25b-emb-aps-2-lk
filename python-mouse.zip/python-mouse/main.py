import serial
import struct
import time
import ctypes

SERIAL_PORT = 'COM8' 
BAUD_RATE = 115200

# sensibilidade  (quanto maior, mais lento)
SENSITIVITY = 12.5 

# Inversão de eixos originais
INVERT_X = -1
INVERT_Y = 1

# Deadzone original (Filtrar tremedeira no Python)
DEADZONE_PYTHON = 3.0

# ==================== MOTOR DE BAIXO NÍVEL (CTYPES) ====================
# Isso é o que faz funcionar dentro do AimLabs
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004

def move_mouse_raw(x, y):
    # Envia movimento direto pro Kernel do Windows
    ctypes.windll.user32.mouse_event(MOUSEEVENTF_MOVE, int(x), int(y), 0, 0)

def click_mouse():
    ctypes.windll.user32.mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    time.sleep(0.01) # Pequeno delay para registrar o clique
    ctypes.windll.user32.mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)

def press_reload():
    # Código virtual da tecla R = 0x52
    ctypes.windll.user32.keybd_event(0x52, 0, 0, 0)
    time.sleep(0.05)
    ctypes.windll.user32.keybd_event(0x52, 0, 0x0002, 0) # Release

# ==================== CONFIGURAÇÃO INICIAL ====================
print(f"Tentando conectar na {SERIAL_PORT}...")

try:
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.01)
    ser.reset_input_buffer()
    print(f"Conectado! Configurações restauradas (Sens: {SENSITIVITY}).")
    print("Ctrl+C para sair.")
except Exception as e:
    print(f"Erro ao abrir serial: {e}")
    exit()

# Acumuladores de precisão (Mantidos para suavidade)
rem_x = 0.0
rem_y = 0.0

packet_count = 0

buffer = b''

# ==================== LOOP PRINCIPAL ====================
try:
    while True:
        chunk = ser.read(ser.in_waiting or 1)
        if not chunk: continue
        buffer += chunk
        
        while len(buffer) >= 4:
            # Sincronia
            if buffer[0] != 0xFF:
                buffer = buffer[1:]
                continue
            
            # Decodificação
            axis = buffer[1]
            val_low = buffer[2]
            val_high = buffer[3]
            buffer = buffer[4:] # Remove pacote lido
            
            # Reconstrói int16
            value = struct.unpack('<h', bytes([val_low, val_high]))[0]
            packet_count += 1

            # === EIXO X ===
            if axis == 0:
                # 1. Aplica Deadzone Original
                if abs(value) < DEADZONE_PYTHON:
                    continue

                # 2. Calcula com suas configurações (Invert + Sensibilidade)
                # Adiciona o acumulador para não perder precisão com sensibilidade alta
                raw_move = (value * INVERT_X) / SENSITIVITY
                total_move = raw_move + rem_x
                
                # 3. Separa parte inteira
                move = int(total_move)
                rem_x = total_move - move
                
                # 4. Envia comando Low Level
                if move != 0:
                    move_mouse_raw(move, 0)

            # === EIXO Y ===
            elif axis == 1:
                if abs(value) < DEADZONE_PYTHON:
                    continue

                raw_move = (value * INVERT_Y) / SENSITIVITY
                total_move = raw_move + rem_y
                
                move = int(total_move)
                rem_y = total_move - move
                
                if move != 0:
                    move_mouse_raw(0, move)

            # === BOTÕES ===
            elif axis == 3: # Single
                click_mouse()
                
            elif axis == 6: # Burst
                click_mouse()
                
            elif axis == 7: # Reload
                press_reload()

            # Debug a cada 100 pacotes (igual ao seu original)
            if packet_count % 100 == 0:
                print(f"\r Pacotes: {packet_count}", end='')

except KeyboardInterrupt:
    print("\nEncerrado.")
finally:
    ser.close()